#!/usr/bin/env python3
"""VDI 云桌面管理平台 2.0 - 多节点全面支持版"""
import os, time, hashlib, uuid, logging, secrets, csv, io, json, subprocess, datetime
from functools import wraps
from datetime import datetime, timezone, timedelta
import mysql.connector
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from proxmoxer import ProxmoxAPI
from apscheduler.schedulers.background import BackgroundScheduler
import yaml
import requests as http_requests

def load_config():
    path = os.environ.get("VDI_CONFIG", "/opt/vdi-deploy/vdi-web/config.yaml")
    with open(path) as f: cfg = yaml.safe_load(f)
    if cfg.get("guacamole",{}).get("port") is None: cfg["guacamole"]["port"]=""
    return cfg

CONFIG=load_config()
app=Flask(__name__)
app.secret_key=CONFIG["web"]["secret_key"]
logging.basicConfig(level=logging.INFO)

def format_bytes(b):
    if not b or b==0: return "0 B"
    u=["B","KB","MB","GB","TB"]; i,s=0,float(b)
    while s>=1024 and i<len(u)-1: s/=1024; i+=1
    return f"{s:.1f} {u[i]}"

def get_db(): return mysql.connector.connect(**CONFIG["database"])

def format_expire_at(expire_at_str):
    if not expire_at_str:
        return None
    if isinstance(expire_at_str, datetime):
        dt = expire_at_str
    else:
        s = str(expire_at_str).replace('T', ' ')
        if len(s) == 16:
            s += ':00'
        dt = datetime.strptime(s, '%Y-%m-%d %H:%M:%S')
    beijing_tz = timezone(timedelta(hours=8))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=beijing_tz)
    else:
        dt = dt.astimezone(beijing_tz)
    dt_utc = dt.astimezone(timezone.utc)
    return dt_utc.strftime('%Y-%m-%d %H:%M:%S')

# ==================== Proxmox 管理类 ====================
class PM:
    def __init__(self, node_config=None):
        if node_config:
            self.n = node_config["node"]
            self.a = ProxmoxAPI(
                node_config["host"],
                user=node_config.get("user", "root@pam"),
                token_name=node_config.get("token_name"),
                token_value=node_config.get("token_value"),
                verify_ssl=node_config.get("verify_ssl", False)
            )
        else:
            p = CONFIG["proxmox"]
            self.n = p["node"]
            self.a = ProxmoxAPI(p["host"], user=p["user"], token_name=p["token_name"],
                                token_value=p["token_value"], verify_ssl=p["verify_ssl"])
    def _wait(self,u):
        na=self.a.nodes(self.n)
        while True:
            s=na.tasks(u).status.get()
            if s["status"]=="stopped": return s["exitstatus"]=="OK"
            time.sleep(2)
    def get_templates(self):
        return [{"vmid":v["vmid"],"name":v.get("name","")} for v in self.a.nodes(self.n).qemu.get() if v.get("template")==1]
    def get_storages(self):
        r=[]
        for s in self.a.nodes(self.n).storage.get():
            if s.get("content") and "images" in s["content"].split(","):
                t,u,a=s.get("total",0),s.get("used",0),s.get("avail",0)
                r.append({"storage":s["storage"],"type":s.get("type",""),"total":t,"used":u,"avail":a,
                          "percent":round(u/max(t,1)*100,1),"total_str":format_bytes(t),
                          "used_str":format_bytes(u),"avail_str":format_bytes(a)})
        return r
    def get_node_status(self):
        try:
            s=self.a.nodes(self.n).status.get(); m=s.get("memory",{})
            return {"cpu":round(s.get("cpu",0)*100,1),"cpu_cores":s.get("cpuinfo",{}).get("cpus",0),
                    "memory_total":m.get("total",0),"memory_used":m.get("used",0),
                    "memory_percent":round(m.get("used",0)/max(m.get("total",1),1)*100,1),
                    "memory_total_str":format_bytes(m.get("total",0)),
                    "memory_used_str":format_bytes(m.get("used",0))}
        except: return {"cpu":0,"memory_percent":0}
    def get_vm_status(self,i):
        try: return self.a.nodes(self.n).qemu(i).status.current.get().get("status","unknown")
        except: return "unknown"
    
    # 带有自动降级的 clone_vm
    def clone_vm(self, t, i, n, s=None, f=0, auto_full=True, fallback_storage=None):
        na = self.a.nodes(self.n)
        p = {"newid": i, "name": n, "full": f, "target": self.n}
        if f == 1 and s:
            p["storage"] = s
        try:
            if not self._wait(na.qemu(t).clone.post(**p)):
                raise Exception("克隆任务失败")
            na.qemu(i).status.start.post()
            return
        except Exception as e:
            if f == 0 and auto_full and "Linked clone feature is not supported" in str(e):
                if not fallback_storage:
                    raise Exception("链接克隆失败，且未提供备用存储，无法自动降级")
                logging.warning(f"链接克隆失败，使用存储 {fallback_storage} 自动降级为完整克隆")
                p2 = {"newid": i, "name": n, "full": 1, "target": self.n, "storage": fallback_storage}
                if not self._wait(na.qemu(t).clone.post(**p2)):
                    raise Exception("完整克隆任务失败")
                na.qemu(i).status.start.post()
                return
            else:
                raise

    def get_vm_ip(self,i,to=120):
        na=self.a.nodes(self.n); st=time.time()
        while time.time()-st<to:
            try:
                for iface in na.qemu(i).agent("network-get-interfaces").get().get("result",[]):
                    if iface.get("name")=="lo": continue
                    for ip in iface.get("ip-addresses",[]):
                        if ip["ip-address-type"]=="ipv4": return ip["ip-address"]
            except: pass
            time.sleep(5)
        raise Exception("获取IP超时")
    def start_vm(self,i): self.a.nodes(self.n).qemu(i).status.start.post()
    def stop_vm(self,i): self.a.nodes(self.n).qemu(i).status.stop.post()
    def destroy_vm(self,i):
        na=self.a.nodes(self.n)
        try: na.qemu(i).status.stop.post(); time.sleep(3)
        except: pass
        na.qemu(i).delete()
    def create_snapshot(self,i,n,d=""): self.a.nodes(self.n).qemu(i).snapshot.post(snapname=n,description=d)
    def list_snapshots(self,i):
        try: return self.a.nodes(self.n).qemu(i).snapshot.get()
        except: return []
    def rollback_snapshot(self,i,n): self.a.nodes(self.n).qemu(i).snapshot(n).rollback.post()
    def delete_snapshot(self,i,n): self.a.nodes(self.n).qemu(i).snapshot(n).delete()
    def get_vm_rrd(self, vmid, timeframe="hour"):
        try: return self.a.nodes(self.n).qemu(vmid).rrddata.get(timeframe=timeframe)
        except: return None

# ==================== 数据库操作类 ====================
class DB:
    def __init__(self): self.c=get_db()
    def __enter__(self): return self
    def __exit__(self,*a): self.c.close()
    def close(self):
        if self.c: self.c.close()
    def _hash(self,p):
        s=secrets.token_bytes(32).hex().upper(); return s, hashlib.sha256((p+s).encode()).hexdigest().upper()
    def add_user(self,u,p):
        cur=self.c.cursor()
        cur.execute("SELECT entity_id FROM guacamole_entity WHERE name=%s AND type='USER'",(u,))
        r=cur.fetchone(); eid=r[0] if r else None
        if not eid: cur.execute("INSERT INTO guacamole_entity(name,type) VALUES(%s,'USER')",(u,)); eid=cur.lastrowid
        s,h=self._hash(p)
        cur.execute("""INSERT INTO guacamole_user(entity_id,password_salt,password_hash,password_date)
                       VALUES(%s,UNHEX(%s),UNHEX(%s),NOW())
                       ON DUPLICATE KEY UPDATE password_salt=VALUES(password_salt),password_hash=VALUES(password_hash)""",
                    (eid,s,h))
        self.c.commit(); return eid
    def add_connection(self, n, ip, vu, vp, vi, sec, node_id=None, group_id=None, expire_at=None, tenant_id=None):
        rdp=CONFIG["rdp_defaults"]; cur=self.c.cursor()
        cur.execute("INSERT INTO guacamole_connection(connection_name,protocol) VALUES(%s,'rdp')",(n,)); cid=cur.lastrowid
        params=[("hostname",ip),("port",rdp["port"]),("username",vu),("password",vp),
                ("security",sec),("vmid",str(vi))]
        if node_id: params.append(("node_id", str(node_id)))
        if group_id: params.append(("group_id", str(group_id)))
        if expire_at: params.append(("expire_at", expire_at))
        if tenant_id: params.append(("tenant_id", str(tenant_id)))
        beijing_tz = timezone(timedelta(hours=8))
        created_at_str = datetime.now(beijing_tz).strftime("%Y-%m-%d %H:%M:%S")
        params.append(("created_at", created_at_str))
        for k,v in rdp.items():
            if k not in ("port","security"): params.append((k,v))
        for p,v in params:
            cur.execute("""INSERT INTO guacamole_connection_parameter(connection_id,parameter_name,parameter_value)
                           VALUES(%s,%s,%s)""",(cid,p,v))
        self.c.commit(); return cid
    def authorize(self,e,c): self.c.cursor().execute(
        "INSERT INTO guacamole_connection_permission(entity_id,connection_id,permission) VALUES(%s,%s,'READ')",(e,c)); self.c.commit()
    def list_desktops(self, tenant_id=None):
        cur=self.c.cursor(dictionary=True)
        sql = """SELECT c.connection_id,c.connection_name,e.name username,
                        host.parameter_value ip,
                        vmid_param.parameter_value vmid,
                        vu.parameter_value vm_username,
                        sec.parameter_value security_mode,
                        node.parameter_value node_id,
                        grp.parameter_value group_id,
                        exp.parameter_value expire_at,
                        crt.parameter_value created_at,
                        tn.parameter_value tenant_id,
                        g.name as group_name,
                        nd.node as node_name
                 FROM guacamole_connection c
                 LEFT JOIN guacamole_connection_permission p ON c.connection_id=p.connection_id
                 LEFT JOIN guacamole_entity e ON p.entity_id=e.entity_id
                 LEFT JOIN guacamole_connection_parameter host ON c.connection_id=host.connection_id AND host.parameter_name='hostname'
                 LEFT JOIN guacamole_connection_parameter vmid_param ON c.connection_id=vmid_param.connection_id AND vmid_param.parameter_name='vmid'
                 LEFT JOIN guacamole_connection_parameter vu ON c.connection_id=vu.connection_id AND vu.parameter_name='username'
                 LEFT JOIN guacamole_connection_parameter sec ON c.connection_id=sec.connection_id AND sec.parameter_name='security'
                 LEFT JOIN guacamole_connection_parameter node ON c.connection_id=node.connection_id AND node.parameter_name='node_id'
                 LEFT JOIN guacamole_connection_parameter grp ON c.connection_id=grp.connection_id AND grp.parameter_name='group_id'
                 LEFT JOIN guacamole_connection_parameter exp ON c.connection_id=exp.connection_id AND exp.parameter_name='expire_at'
                 LEFT JOIN guacamole_connection_parameter crt ON c.connection_id=crt.connection_id AND crt.parameter_name='created_at'
                 LEFT JOIN guacamole_connection_parameter tn ON c.connection_id=tn.connection_id AND tn.parameter_name='tenant_id'
                 LEFT JOIN vdi_desktop_group g ON grp.parameter_value = g.id
                 LEFT JOIN vdi_proxmox_nodes nd ON node.parameter_value = nd.id"""
        if tenant_id:
            sql += " WHERE tn.parameter_value = %s OR tn.parameter_value IS NULL"
            cur.execute(sql, (str(tenant_id),))
        else:
            cur.execute(sql)
        return cur.fetchall()
    def remove_connection(self,c):
        cur=self.c.cursor()
        for t in["guacamole_connection_parameter","guacamole_connection_permission","guacamole_connection"]:
            cur.execute(f"DELETE FROM {t} WHERE connection_id=%s",(c,))
        self.c.commit()
    def remove_user(self,e,u):
        cur=self.c.cursor()
        cur.execute("DELETE FROM guacamole_connection_permission WHERE entity_id=%s",(e,))
        cur.execute("DELETE FROM guacamole_user WHERE entity_id=%s",(e,))
        cur.execute("DELETE FROM guacamole_entity WHERE entity_id=%s AND name=%s",(e,u))
        self.c.commit()
    def get_entity(self,u):
        cur=self.c.cursor(); cur.execute("SELECT entity_id FROM guacamole_entity WHERE name=%s AND type='USER'",(u,))
        r=cur.fetchone(); return r[0] if r else None
    def validate_user_password(self,u,p):
        cur=self.c.cursor(dictionary=True)
        cur.execute("""SELECT u.password_salt,u.password_hash FROM guacamole_user u
                       JOIN guacamole_entity e ON u.entity_id=e.entity_id
                       WHERE e.name=%s AND e.type='USER'""",(u,))
        r=cur.fetchone()
        if not r: return False
        return hashlib.sha256((p+r['password_salt'].hex().upper()).encode()).hexdigest().upper()==r['password_hash'].hex().upper()
    def add_schedule(self,c,i,a,t,node_id=None):
        self.c.cursor().execute(
            "INSERT INTO vdi_schedule(connection_id,vmid,action,execute_at,node_id) VALUES(%s,%s,%s,%s,%s)",
            (c,i,a,t,node_id)
        )
        self.c.commit()
    def get_pending_schedules(self):
        cur=self.c.cursor(dictionary=True)
        cur.execute("SELECT * FROM vdi_schedule WHERE executed=0 AND execute_at<=NOW()")
        return cur.fetchall()
    def mark_schedule_executed(self,i):
        self.c.cursor().execute("UPDATE vdi_schedule SET executed=1 WHERE id=%s",(i,))
        self.c.commit()
    def update_connection(self, conn_id, ip, vm_username, vm_password, security_mode):
        cur = self.c.cursor()
        for pname, pval in [("hostname", ip), ("username", vm_username), ("security", security_mode)]:
            cur.execute("UPDATE guacamole_connection_parameter SET parameter_value=%s WHERE connection_id=%s AND parameter_name=%s",
                        (pval, conn_id, pname))
        if vm_password:
            cur.execute("UPDATE guacamole_connection_parameter SET parameter_value=%s WHERE connection_id=%s AND parameter_name='password'",
                        (vm_password, conn_id))
        self.c.commit()
    def update_guac_user(self, entity_id, new_username=None, new_password=None):
        cur = self.c.cursor()
        if new_username:
            cur.execute("UPDATE guacamole_entity SET name=%s WHERE entity_id=%s", (new_username, entity_id))
        if new_password:
            s,h = self._hash(new_password)
            cur.execute("UPDATE guacamole_user SET password_salt=UNHEX(%s), password_hash=UNHEX(%s), password_date=NOW() WHERE entity_id=%s",
                        (s,h,entity_id))
        self.c.commit()
    def get_connection_param(self, conn_id, param_name):
        cur = self.c.cursor()
        cur.execute("SELECT parameter_value FROM guacamole_connection_parameter WHERE connection_id=%s AND parameter_name=%s",
                    (conn_id, param_name))
        r = cur.fetchone()
        return r[0] if r else None
    def set_connection_param(self, conn_id, param_name, param_value):
        cur = self.c.cursor()
        cur.execute("""INSERT INTO guacamole_connection_parameter(connection_id,parameter_name,parameter_value)
                       VALUES(%s,%s,%s) ON DUPLICATE KEY UPDATE parameter_value=VALUES(parameter_value)""",
                    (conn_id, param_name, param_value))
        self.c.commit()

def login_required(f):
    @wraps(f)
    def d(*a,**k):
        if not session.get("logged_in"): return redirect(url_for("login"))
        return f(*a,**k)
    return d

# ==================== 辅助函数 ====================
def get_pm_by_vmid(vmid):
    """根据 VMID 获取对应的 Proxmox 节点实例（直接从数据库查询）"""
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    # 查询该 vmid 对应的 node_id
    cur.execute("""
        SELECT node.parameter_value AS node_id
        FROM guacamole_connection c
        JOIN guacamole_connection_parameter vmid_param ON c.connection_id = vmid_param.connection_id 
            AND vmid_param.parameter_name = 'vmid'
        LEFT JOIN guacamole_connection_parameter node ON c.connection_id = node.connection_id 
            AND node.parameter_name = 'node_id'
        WHERE vmid_param.parameter_value = %s
    """, (str(vmid),))
    row = cur.fetchone()
    cur.close()
    conn.close()
    node_id = row.get("node_id") if row else None
    node_config = None
    if node_id:
        conn2 = get_db()
        cur2 = conn2.cursor(dictionary=True)
        cur2.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
        node_config = cur2.fetchone()
        cur2.close()
        conn2.close()
    return PM(node_config) if node_config else PM()
# ==================== 定时任务调度器 ====================
scheduler=BackgroundScheduler()
def process():
    logging.info("执行到期回收检查...")
    db=DB()
    try:
        # 处理普通定时任务
        for t in db.get_pending_schedules() or []:
            try:
                node_config = None
                if t.get("node_id"):
                    conn = get_db()
                    cur = conn.cursor(dictionary=True)
                    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (t["node_id"],))
                    node_config = cur.fetchone()
                    cur.close()
                    conn.close()
                pm = PM(node_config) if node_config else PM()
                if t["action"] == "startup":
                    pm.start_vm(t["vmid"])
                elif t["action"] == "shutdown":
                    pm.stop_vm(t["vmid"])
                elif t["action"] == "destroy":
                    pm.destroy_vm(t["vmid"])
                elif t["action"] == "snapshot":
                    pm.create_snapshot(t["vmid"], f"auto_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
                db.mark_schedule_executed(t["id"])
            except Exception as e:
                logging.error(f"定时任务执行失败: {e}")
        # 处理到期桌面回收
        cur = db.c.cursor(dictionary=True)
        cur.execute("""
            SELECT c.connection_id, c.connection_name,
                   vmid_param.parameter_value as vmid,
                   node_param.parameter_value as node_id
            FROM guacamole_connection c
            JOIN guacamole_connection_parameter exp ON c.connection_id = exp.connection_id AND exp.parameter_name = 'expire_at'
            JOIN guacamole_connection_parameter vmid_param ON c.connection_id = vmid_param.connection_id AND vmid_param.parameter_name = 'vmid'
            LEFT JOIN guacamole_connection_parameter node_param ON c.connection_id = node_param.connection_id AND node_param.parameter_name = 'node_id'
            WHERE STR_TO_DATE(exp.parameter_value, '%Y-%m-%d %H:%i:%s') < UTC_TIMESTAMP()
              AND NOT EXISTS (
                  SELECT 1 FROM guacamole_connection_parameter p2
                  WHERE p2.connection_id = c.connection_id
                    AND p2.parameter_name = 'expired_handled'
              )
        """)
        expired = cur.fetchall()
        for e in expired:
            try:
                node_config = None
                if e.get("node_id"):
                    conn = get_db()
                    cur2 = conn.cursor(dictionary=True)
                    cur2.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (e["node_id"],))
                    node_config = cur2.fetchone()
                    cur2.close()
                    conn.close()
                pm = PM(node_config) if node_config else PM()
                vmid = int(e["vmid"])
                pm.destroy_vm(vmid)
                cur3 = db.c.cursor()
                cur3.execute("""INSERT INTO guacamole_connection_parameter(connection_id,parameter_name,parameter_value)
                                VALUES(%s,'expired_handled','1') ON DUPLICATE KEY UPDATE parameter_value='1'""",
                             (e["connection_id"],))
                db.c.commit()
                send_notification(f"桌面 {e['connection_name']} 已到期自动销毁")
                logging.info(f"到期桌面 {e['connection_name']} (VMID:{vmid}) 已自动销毁")
            except Exception as ex:
                logging.error(f"到期回收失败: {ex}")
    finally:
        db.close()
scheduler.add_job(process,'interval',minutes=1)
if not scheduler.running: scheduler.start()

def send_notification(msg):
    try:
        conn = get_db(); cur = conn.cursor(dictionary=True)
        cur.execute("SELECT type, config FROM vdi_notify_config WHERE enabled=1")
        configs = cur.fetchall(); cur.close(); conn.close()
        for cfg in configs:
            if cfg["type"] == "webhook":
                try:
                    url = json.loads(cfg["config"]).get("webhook_url")
                    if url: http_requests.post(url, json={"message": msg}, timeout=5)
                except: pass
    except: pass

def restore_backup(filepath):
    try:
        db = CONFIG["database"]
        if filepath.endswith('.gz'):
            cmd = f"gunzip -c {filepath} | docker exec -i guac-mysql mysql -u{db['user']} -p{db['password']} {db['database']}"
        else:
            cmd = f"cat {filepath} | docker exec -i guac-mysql mysql -u{db['user']} -p{db['password']} {db['database']}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            error_msg = result.stderr.strip() or "未知错误"
            logging.error(f"恢复命令失败: {result.stderr}")
            return False, error_msg
        return True, "恢复成功"
    except Exception as e:
        logging.error(f"恢复异常: {e}")
        return False, str(e)

# ==================== index路由状态获取 ====================
@app.route("/")
@login_required
def index():
    pm=PM(); tpl=pm.get_templates(); sto=pm.get_storages(); ns=pm.get_node_status()
    db=DB(); des=db.list_desktops(); db.close()
    rc=0
    sc=0
    # ---- 修改开始：逐台获取状态，根据 node_id 选择 PM ----
    for d in des:
        if d.get("vmid"):
            node_id = d.get("node_id")
            node_config = None
            if node_id:
                try:
                    conn = get_db()
                    cur = conn.cursor(dictionary=True)
                    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
                    node_config = cur.fetchone()
                    cur.close()
                    conn.close()
                except Exception:
                    node_config = None
            pm_tmp = PM(node_config) if node_config else PM()
            try:
                d["status"] = pm_tmp.get_vm_status(int(d["vmid"]))
            except:
                d["status"] = "unknown"
        else:
            d["status"] = "N/A"
        if d["status"] == "running":
            rc += 1
        elif d["status"] == "stopped":
            sc += 1
    # ---- 修改结束 ----
    conn = get_db(); cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE enabled=1")
    nodes = cur.fetchall()
    cur.execute("SELECT * FROM vdi_desktop_group ORDER BY name")
    groups = cur.fetchall()
    cur.close(); conn.close()
    return render_template("index.html", templates=tpl, storages=sto, desktops=des,
                           node_status=ns, running_count=rc, stopped_count=sc,
                           guac_config=CONFIG["guacamole"], nodes=nodes, groups=groups,
                           current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

#---------登录路由------------
@app.route("/login",methods=["GET","POST"])
def login():
    e=None
    if request.method=="POST":
        if request.form.get("username","").strip()=="admin" and request.form.get("password","").strip()==CONFIG["web"]["admin_password"]:
            session["logged_in"]=True; return redirect(url_for("index"))
        e="用户名或密码错误"
    return render_template("login.html",error=e)

@app.route("/logout")
def logout(): session.pop("logged_in",None); return redirect(url_for("login"))

# -------- 多节点 API --------
@app.route("/api/node_templates/<int:node_id>")
@login_required
def api_node_templates(node_id):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
    node = cur.fetchone()
    cur.close()
    conn.close()
    if not node:
        return jsonify({"error": "节点不存在或未启用"}), 404
    try:
        pm = PM(node)
        templates = pm.get_templates()
        return jsonify({"templates": templates})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/node_storages/<int:node_id>")
@login_required
def api_node_storages(node_id):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
    node = cur.fetchone()
    cur.close()
    conn.close()
    if not node:
        return jsonify({"error": "节点不存在或未启用"}), 404
    try:
        pm = PM(node)
        storages = pm.get_storages()
        return jsonify({"storages": storages})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------- 创建桌面（支持节点选择）--------
@app.route("/add", methods=["POST"])
@login_required
def add():
    gu = request.form["guac_username"].strip()
    gp = request.form["guac_password"].strip()
    vu = request.form["vm_username"].strip()
    vp = request.form["vm_password"].strip()
    nm = request.form["vmname"].strip()
    vi = int(request.form["vmid"])
    ti = int(request.form["template"])
    im = request.form.get("ip_mode", "auto")
    mi = request.form.get("manual_ip", "").strip()
    se = request.form.get("security_mode", "any")
    cm = request.form.get("clone_mode", "link")
    fu = 1 if cm == "full" else 0
    sg = request.form.get("storage", "").strip() or None
    node_id = request.form.get("node_id", "").strip()
    group_id = request.form.get("group_id", "").strip()
    expire_at = request.form.get("expire_at", "").strip()
    expire_at = format_expire_at(expire_at) if expire_at else None

    node_config = None
    fallback_storage = CONFIG["proxmox"].get("default_storage", "local-lvm")
    if node_id:
        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
        node_config = cur.fetchone()
        cur.close()
        conn.close()
        if not node_config:
            flash("选中的节点不存在或未启用", "danger")
            return redirect(url_for("index"))
        fallback_storage = node_config.get("default_storage", "local-lvm")

    pm = PM(node_config) if node_config else PM()
    if fu == 1 and not sg:
        sg = fallback_storage

    try:
        pm.clone_vm(ti, vi, nm, sg, fu, fallback_storage=fallback_storage)
    except Exception as ex:
        flash(f"克隆失败: {ex}", "danger")
        return redirect(url_for("index"))

    ip = mi if im == "manual" and mi else None
    if not ip:
        try:
            ip = pm.get_vm_ip(vi, 180)
        except:
            flash("获取IP失败，请手动设置", "warning")

    if ip:
        db = DB()
        try:
            ei = db.add_user(gu, gp)
            ci = db.add_connection(nm, ip, vu, vp, vi, se,
                                   node_id if node_id else None,
                                   group_id if group_id else None,
                                   expire_at if expire_at else None)
            db.authorize(ei, ci)
            flash(f"桌面 {nm} 创建成功", "success")
        except Exception as ex:
            flash(f"数据库错误: {ex}", "danger")
        finally:
            db.close()
    else:
        flash("未获取到 IP，请检查虚拟机网络", "warning")

    return redirect(url_for("index"))

@app.route("/add_existing", methods=["POST"])
@login_required
def add_existing():
    guac_username = request.form["guac_username"].strip()
    guac_password = request.form["guac_password"].strip()
    vm_username = request.form["vm_username"].strip()
    vm_password = request.form["vm_password"].strip()
    vmname = request.form["vmname"].strip()
    ip = request.form["ip"].strip()
    vmid = request.form.get("vmid", "").strip()
    security_mode = request.form.get("security_mode", "any").strip()
    node_id = request.form.get("node_id", "").strip()
    group_id = request.form.get("group_id", "").strip()
    expire_at = request.form.get("expire_at", "").strip()
    expire_at = format_expire_at(expire_at) if expire_at else None
    if not ip or not vmname:
        flash("IP 和连接名称不能为空", "danger")
        return redirect(url_for("index"))
    db = DB()
    try:
        eid = db.add_user(guac_username, guac_password)
        cid = db.add_connection(vmname, ip, vm_username, vm_password,
                                vmid if vmid else "0", security_mode,
                                node_id if node_id else None,
                                group_id if group_id else None,
                                expire_at if expire_at else None)
        db.authorize(eid, cid)
        flash(f"已添加主机 {vmname} (IP: {ip})", "success")
    except Exception as e:
        flash(f"添加失败: {e}", "danger")
    finally:
        db.close()
    return redirect(url_for("index"))

@app.route("/batch_add", methods=["POST"])
@login_required
def batch_add():
    f = request.files.get("csv_file")
    if not f:
        flash("请上传CSV文件", "danger")
        return redirect(url_for("index"))
    stream = io.StringIO(f.stream.read().decode("UTF-8"))
    reader = csv.DictReader(stream)
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE enabled = 1")
    all_nodes = {str(node["id"]): node for node in cur.fetchall()}
    cur.close()
    conn.close()
    sc = 0
    el = []
    db = DB()
    for row in reader:
        try:
            gu = row["guac_username"].strip()
            gp = row["guac_password"].strip()
            vu = row["vm_username"].strip()
            vp = row["vm_password"].strip()
            nm = row["vmname"].strip()
            vi = int(row["vmid"])
            ti = int(row["template"])
            cm = row.get("clone_mode", "full").strip()
            fu = 1 if cm == "full" else 0
            ip_mode = row.get("ip_mode", "auto").strip()
            manual_ip = row.get("manual_ip", "").strip()
            sec = row.get("security_mode", "any").strip()
            node_id = row.get("node_id", "").strip()
            group_id = row.get("group_id", "").strip()
            expire_at = row.get("expire_at", "").strip()
            expire_at = format_expire_at(expire_at) if expire_at else None

            node_config = None
            fallback_storage = CONFIG["proxmox"].get("default_storage", "local-lvm")
            if node_id and node_id in all_nodes:
                node_config = all_nodes[node_id]
                fallback_storage = node_config.get("default_storage", "local-lvm")
            pm = PM(node_config) if node_config else PM()

            sg = row.get("storage", "").strip() or None
            if fu == 1 and not sg:
                sg = fallback_storage

            pm.clone_vm(ti, vi, nm, sg, fu, fallback_storage=fallback_storage)

            ip = manual_ip if ip_mode == "manual" and manual_ip else pm.get_vm_ip(vi, 180)
            if not ip:
                el.append(f"{nm}:IP获取失败")
                continue

            ei = db.add_user(gu, gp)
            ci = db.add_connection(nm, ip, vu, vp, vi, sec,
                                   node_id if node_id else None,
                                   group_id if group_id else None,
                                   expire_at if expire_at else None)
            db.authorize(ei, ci)
            db.c.commit()
            sc += 1
        except Exception as e:
            el.append(f"{nm}: {e}")
    db.c.commit()
    db.close()
    flash(f"批量创建完成，成功: {sc}，失败: {len(el)}", "info" if not el else "warning")
    for err in el[:5]:
        flash(f"  - {err}", "warning")
    return redirect(url_for("index"))

#---------删除路由-----------
@app.route("/delete", methods=["POST"])
@login_required
def delete():
    nm = request.form["vmname"]
    vmid_str = request.form.get("vmid", "0").strip()
    vmid = int(vmid_str) if vmid_str.isdigit() else 0
    db = DB()
    try:
        desktops = db.list_desktops()
        target = next((d for d in desktops if d["connection_name"] == nm), None)
        if not target:
            flash("未找到桌面", "danger")
            return redirect(url_for("index"))
        conn_id = target["connection_id"]
        db.remove_connection(conn_id)
        username = target.get("username")
        if username:
            entity_id = db.get_entity(username)
            if entity_id:
                db.remove_user(entity_id, username)
        flash(f"桌面 {nm} 已删除", "success")
        # 销毁虚拟机（使用 target 中的节点信息）
        if vmid > 0:
            node_id = target.get("node_id")
            node_config = None
            if node_id:
                conn = get_db()
                cur = conn.cursor(dictionary=True)
                cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
                node_config = cur.fetchone()
                cur.close()
                conn.close()
            prox = PM(node_config) if node_config else PM()
            if prox.get_vm_status(vmid):
                prox.destroy_vm(vmid)
    except Exception as e:
        flash(f"删除失败: {e}", "danger")
    finally:
        db.close()
    return redirect(url_for("index"))


@app.route("/power", methods=["POST"])
@login_required
def power():
    vi = int(request.form["vmid"])
    a = request.form["action"]
    pm = get_pm_by_vmid(vi)
    if a == "start":
        pm.start_vm(vi)
    elif a == "stop":
        pm.stop_vm(vi)
    flash(f"虚拟机 {vi} 已{'开机' if a=='start' else '关机'}", "success")
    return redirect(url_for("index"))

@app.route("/update", methods=["POST"])
@login_required
def update_desktop():
    conn_id = int(request.form["conn_id"])
    ip = request.form["ip"].strip()
    vm_username = request.form["vm_username"].strip()
    vm_password = request.form["vm_password"].strip()
    security_mode = request.form["security_mode"].strip()
    guac_username = request.form.get("guac_username", "").strip()
    guac_password = request.form.get("guac_password", "").strip()
    group_id = request.form.get("group_id", "").strip()
    expire_at = request.form.get("expire_at", "").strip()
    expire_at = format_expire_at(expire_at) if expire_at else None
    if not ip or not vm_username:
        flash("IP 和虚拟机用户名不能为空","danger")
        return redirect(url_for("index"))
    db = DB()
    try:
        db.update_connection(conn_id, ip, vm_username, vm_password, security_mode)
        if group_id:
            db.set_connection_param(conn_id, "group_id", group_id)
        if expire_at:
            db.set_connection_param(conn_id, "expire_at", expire_at)
        if guac_username or guac_password:
            cur = db.c.cursor(dictionary=True)
            cur.execute("""SELECT e.entity_id,e.name FROM guacamole_connection_permission p
                           JOIN guacamole_entity e ON p.entity_id=e.entity_id
                           WHERE p.connection_id=%s AND e.type='USER'""", (conn_id,))
            row = cur.fetchone()
            if row:
                db.update_guac_user(row["entity_id"],
                                    new_username=guac_username if guac_username != row["name"] else None,
                                    new_password=guac_password if guac_password else None)
        flash("连接参数已更新","success")
    except Exception as e:
        flash(f"更新失败: {e}","danger")
    finally:
        db.close()
    return redirect(url_for("index"))

@app.route("/snapshot", methods=["POST"])
@login_required
def snapshot():
    vi = int(request.form["vmid"])
    a = request.form["action"]
    pm = get_pm_by_vmid(vi)
    if a == "create":
        pm.create_snapshot(vi, f"snap_{int(time.time())}")
        flash("快照已创建", "success")
    elif a == "list":
        return jsonify(pm.list_snapshots(vi))
    elif a == "rollback":
        pm.rollback_snapshot(vi, request.form["snapname"])
        flash("已回滚", "success")
    elif a == "delete":
        pm.delete_snapshot(vi, request.form["snapname"])
        flash("快照已删除", "success")
    return redirect(url_for("index"))

@app.route("/schedule", methods=["POST"])
@login_required
def schedule():
    nm = request.form["vmname"]
    vi = int(request.form["vmid"])
    a = request.form["schedule_action"]
    el = request.form["execute_at"]
    dt = datetime.fromisoformat(el).replace(tzinfo=timezone(timedelta(hours=8))).astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    db = DB()
    ds = db.list_desktops()
    target = next((d for d in ds if d["connection_name"] == nm), None)
    if target:
        node_id = target.get("node_id")
        db.add_schedule(target["connection_id"], vi, a, dt, node_id)
        db.close()
        flash("定时任务已添加", "success")
    else:
        db.close()
        flash("未找到对应桌面", "warning")
    return redirect(url_for("index"))

@app.route("/api/schedules")
@login_required
def api_schedules():
    c=get_db(); cur=c.cursor(dictionary=True)
    cur.execute("""SELECT s.*,c.connection_name FROM vdi_schedule s
                   LEFT JOIN guacamole_connection c ON s.connection_id=c.connection_id
                   ORDER BY s.execute_at DESC""")
    r=cur.fetchall(); cur.close(); c.close(); return jsonify(r)

@app.route("/schedule/delete", methods=["POST"])
@login_required
def delete_schedule():
    c=get_db(); cur=c.cursor()
    cur.execute("DELETE FROM vdi_schedule WHERE id=%s",(int(request.form["schedule_id"]),))
    c.commit(); cur.close(); c.close()
    flash("定时任务已删除","success"); return redirect(url_for("index"))

@app.route("/audit")
@login_required
def audit():
    p=request.args.get("page",1,type=int); pp=20; c=get_db(); cur=c.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) t FROM vdi_audit_log")
    tp=max(1,(cur.fetchone()["t"]+pp-1)//pp)
    cur.execute("SELECT * FROM vdi_audit_log ORDER BY created_at DESC LIMIT %s OFFSET %s",(pp,(p-1)*pp))
    l=cur.fetchall(); cur.close(); c.close()
    return render_template("audit.html",logs=l,page=p,total_pages=tp)

@app.route("/user", methods=["GET","POST"])
def user():
    if request.method=="POST":
        action=request.form.get("action")
        if action=="login":
            username=request.form["username"].strip(); password=request.form["password"].strip()
            db=DB()
            if db.validate_user_password(username,password):
                session["user"]=username; db.close(); return redirect(url_for("user"))
            db.close(); flash("用户名或密码错误","danger"); return render_template("user_login.html")
        elif action=="change_password":
            if "user" not in session: return redirect(url_for("user"))
            new_password=request.form["new_password"].strip()
            if new_password:
                db=DB(); entity_id=db.get_entity(session["user"])
                if entity_id:
                    s,h=db._hash(new_password); cur=db.c.cursor()
                    cur.execute("UPDATE guacamole_user SET password_salt=UNHEX(%s), password_hash=UNHEX(%s), password_date=NOW() WHERE entity_id=%s",
                                (s,h,entity_id)); db.c.commit()
                db.close(); flash("密码修改成功","success")
            return redirect(url_for("user"))
        elif action=="logout":
            session.pop("user",None); return redirect(url_for("user"))
    if "user" not in session: return render_template("user_login.html")
    username=session["user"]; prox=PM(); db=DB()
    cur=db.c.cursor(dictionary=True)
    cur.execute("""
        SELECT c.connection_id,c.connection_name,host.parameter_value AS ip,
               vmid_param.parameter_value AS vmid,g.connection_group_name AS group_name
        FROM guacamole_connection c
        JOIN guacamole_connection_permission p ON c.connection_id=p.connection_id
        JOIN guacamole_entity e ON p.entity_id=e.entity_id
        LEFT JOIN guacamole_connection_parameter host ON c.connection_id=host.connection_id AND host.parameter_name='hostname'
        LEFT JOIN guacamole_connection_parameter vmid_param ON c.connection_id=vmid_param.connection_id AND vmid_param.parameter_name='vmid'
        LEFT JOIN guacamole_connection_group g ON c.parent_id=g.connection_group_id
        WHERE e.name=%s AND e.type='USER'
    """, (username,))
    desktops=cur.fetchall(); cur.close(); db.close()
    for d in desktops:
        if d.get("vmid"):
            try: d["status"]=prox.get_vm_status(int(d["vmid"]))
            except: d["status"]="unknown"
        else: d["status"]="unknown"
    return render_template("user_desktop.html", username=username, desktops=desktops,
                           guac_config=CONFIG["guacamole"])

@app.route("/batch_power", methods=["POST"])
@login_required
def batch_power():
    vmids = request.form.getlist("vmids[]")
    action = request.form.get("action")
    success = 0
    for vmid in vmids:
        try:
            if vmid and vmid != "N/A":
                pm = get_pm_by_vmid(int(vmid))
                if action == "start":
                    pm.start_vm(int(vmid))
                elif action == "stop":
                    pm.stop_vm(int(vmid))
                success += 1
        except Exception as e:
            logging.error(f"批量操作失败: {e}")
    flash(f"批量操作完成，成功: {success}/{len(vmids)}", "success")
    return redirect(url_for("index"))

#---------------批量删除操作-----------
@app.route("/batch_delete", methods=["POST"])
@login_required
def batch_delete():
    entries = request.form.getlist("entries[]")
    success = 0
    db = DB()
    # 获取所有桌面列表，用于查找目标
    desktops = db.list_desktops()
    for entry in entries:
        parts = entry.split("|")
        if len(parts) >= 3:
            vmid, conn_name, username = parts[0], parts[1], parts[2]
            try:
                # 查找桌面
                target = next((d for d in desktops if d["connection_name"] == conn_name), None)
                if not target:
                    continue

                # --- 关键修改：先获取节点配置，构建 PM ---
                node_id = target.get("node_id")
                node_config = None
                if node_id:
                    conn = get_db()
                    cur = conn.cursor(dictionary=True)
                    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
                    node_config = cur.fetchone()
                    cur.close()
                    conn.close()
                prox = PM(node_config) if node_config else PM()

                # 销毁虚拟机（使用 target 中的 vmid，更可靠）
                if target.get("vmid") and target["vmid"] != "N/A":
                    try:
                        vmid_int = int(target["vmid"])
                        if prox.get_vm_status(vmid_int):
                            prox.destroy_vm(vmid_int)
                    except Exception as e:
                        logging.error(f"销毁 VM {target['vmid']} 失败: {e}")

                # 再删除数据库记录
                db.remove_connection(target["connection_id"])
                if username:
                    eid = db.get_entity(username)
                    if eid:
                        db.remove_user(eid, username)

                success += 1
            except Exception as e:
                logging.error(f"批量删除失败: {e}")
    db.close()
    flash(f"批量删除完成，成功: {success}/{len(entries)}", "success")
    return redirect(url_for("index"))

@app.route("/batch_snapshot", methods=["POST"])
@login_required
def batch_snapshot():
    vmids = request.form.getlist("vmids[]")
    success = 0
    for vmid in vmids:
        try:
            if vmid and vmid != "N/A":
                pm = get_pm_by_vmid(int(vmid))
                pm.create_snapshot(int(vmid), f"batch_{int(time.time())}_{vmid}", "批量快照")
                success += 1
        except Exception as e:
            logging.error(f"批量快照失败: {e}")
    flash(f"批量快照创建完成，成功: {success}/{len(vmids)}", "success")
    return redirect(url_for("index"))

@app.route("/request", methods=["GET","POST"])
def desktop_request():
    if request.method=="POST":
        applicant=request.form.get("applicant","").strip()
        template_id=request.form.get("template_id","").strip()
        vmname=request.form.get("vmname","").strip()
        reason=request.form.get("reason","").strip()
        node_id=request.form.get("node_id","").strip()
        group_id=request.form.get("group_id","").strip()
        expire_at=request.form.get("expire_at","").strip()
        expire_at = format_expire_at(expire_at) if expire_at else None
        if not applicant or not template_id:
            flash("请填写必填项","danger")
            return redirect(url_for("desktop_request"))
        conn=get_db(); cur=conn.cursor()
        cur.execute("""INSERT INTO vdi_desktop_request (applicant, template_id, vmname, reason, node_id, group_id, expire_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                    (applicant, template_id, vmname, reason, node_id, group_id, expire_at))
        conn.commit(); cur.close(); conn.close()
        flash("申请已提交，请等待管理员审批","success")
        return redirect(url_for("desktop_request"))
    prox=PM(); templates=prox.get_templates()
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE enabled=1")
    nodes=cur.fetchall()
    cur.execute("SELECT * FROM vdi_desktop_group ORDER BY name")
    groups=cur.fetchall()
    cur.close(); conn.close()
    return render_template("request.html", templates=templates, nodes=nodes, groups=groups)

@app.route("/approve")
@login_required
def approve_list():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_desktop_request ORDER BY created_at DESC")
    requests=cur.fetchall(); cur.close(); conn.close()
    return render_template("approve.html", requests=requests)

@app.route("/approve_action", methods=["POST"])
@login_required
def approve_action():
    req_id = int(request.form["req_id"])
    action = request.form["action"]
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_desktop_request WHERE id = %s", (req_id,))
    req = cur.fetchone()
    if not req:
        flash("申请不存在", "danger")
        return redirect(url_for("approve_list"))
    if req["status"] != "pending":
        flash("该申请已被处理", "warning")
        return redirect(url_for("approve_list"))
    if action == "approve":
        try:
            node_id = req.get("node_id")
            node_config = None
            fallback_storage = CONFIG["proxmox"].get("default_storage", "local-lvm")
            if node_id:
                cur2 = conn.cursor(dictionary=True)
                cur2.execute("SELECT * FROM vdi_proxmox_nodes WHERE id = %s AND enabled = 1", (node_id,))
                node_config = cur2.fetchone()
                cur2.close()
                if not node_config:
                    flash("选中的节点不存在或未启用", "danger")
                    return redirect(url_for("approve_list"))
                fallback_storage = node_config.get("default_storage", "local-lvm")
            pm = PM(node_config) if node_config else PM()
            vmid = int(time.time()) % 10000 + 1000
            fu = 0  # 审批使用完整克隆
            sg = fallback_storage
            template_id = req["template_id"]
            pm.clone_vm(template_id, vmid, req["vmname"] or f"desk-{req['applicant']}",
                        sg, fu, fallback_storage=fallback_storage)
            db = DB()
            import secrets as _secrets
            password = _secrets.token_hex(8)
            eid = db.add_user(req["applicant"], password)
            ip = pm.get_vm_ip(vmid, 180)
            expire_at = req.get("expire_at")
            cid = db.add_connection(req["vmname"] or f"desk-{req['applicant']}", ip,
                                   "administrator", "", vmid, "any",
                                   node_id if node_id else None,
                                   req.get("group_id"), expire_at)
            db.authorize(eid, cid)
            db.close()
            cur.execute("UPDATE vdi_desktop_request SET status='approved', reviewer='admin', vmid=%s, reviewed_at=NOW() WHERE id=%s",
                        (vmid, req_id))
            conn.commit()
            flash(f"已批准并创建桌面，用户 {req['applicant']} 的密码为 {password}", "success")
        except Exception as e:
            flash(f"创建桌面失败: {e}", "danger")
    else:
        cur.execute("UPDATE vdi_desktop_request SET status='rejected', reviewer='admin', reviewed_at=NOW() WHERE id=%s",
                    (req_id,))
        conn.commit()
        flash("已拒绝该申请", "info")
    cur.close()
    conn.close()
    return redirect(url_for("approve_list"))

@app.route("/groups")
@login_required
def groups_page():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_desktop_group ORDER BY name")
    groups=cur.fetchall(); cur.close(); conn.close()
    return render_template("groups.html", groups=groups)

@app.route("/group_add", methods=["POST"])
@login_required
def group_add():
    name=request.form.get("name","").strip(); desc=request.form.get("description","").strip()
    if name:
        conn=get_db(); cur=conn.cursor()
        cur.execute("INSERT INTO vdi_desktop_group (name, description) VALUES (%s,%s)", (name, desc))
        conn.commit(); cur.close(); conn.close()
        flash("分组已添加","success")
    return redirect(url_for("groups_page"))

#------分组删除----
@app.route("/group_delete", methods=["POST"])
@login_required
def group_delete():
    gid=int(request.form.get("gid",0))
    conn=get_db(); cur=conn.cursor()
    cur.execute("DELETE FROM vdi_desktop_group WHERE id=%s", (gid,))
    conn.commit(); cur.close(); conn.close()
    flash("分组已删除","success")
    return redirect(url_for("groups_page"))

#-----分组修改----
@app.route("/group_update", methods=["POST"])
@login_required
def group_update():
    gid = request.form.get("gid")
    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()

    if not gid or not name:
        flash("ID 和分组名称不能为空", "danger")
        return redirect(url_for("groups_page"))

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        UPDATE vdi_desktop_group
        SET name = %s, description = %s
        WHERE id = %s
    """, (name, description, gid))
    conn.commit()
    cur.close()
    conn.close()

    flash("分组信息已更新", "success")
    return redirect(url_for("groups_page"))

@app.route("/nodes")
@login_required
def nodes_page():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes ORDER BY id")
    nodes=cur.fetchall()
    default_node=CONFIG["proxmox"]
    if not any(n["node"]==default_node["node"] for n in nodes):
        nodes.insert(0, {"id":0, "node":default_node["node"], "host":default_node["host"],
                         "token_name":default_node["token_name"], "enabled":1, "is_default":1})
    cur.close(); conn.close()
    return render_template("nodes.html", nodes=nodes)

@app.route("/node_add", methods=["POST"])
@login_required
def node_add():
    host=request.form.get("host","").strip(); node=request.form.get("node","").strip()
    token_name=request.form.get("token_name","").strip(); token_value=request.form.get("token_value","").strip()
    if host and node:
        conn=get_db(); cur=conn.cursor()
        cur.execute("""INSERT INTO vdi_proxmox_nodes (host, node, token_name, token_value)
                       VALUES (%s,%s,%s,%s)""", (host, node, token_name, token_value))
        conn.commit(); cur.close(); conn.close()
        flash("节点已添加","success")
    return redirect(url_for("nodes_page"))
#-----节点删除按钮
@app.route("/node_delete", methods=["POST"])
@login_required
def node_delete():
    nid=int(request.form.get("nid",0))
    conn=get_db(); cur=conn.cursor()
    cur.execute("DELETE FROM vdi_proxmox_nodes WHERE id=%s", (nid,))
    conn.commit(); cur.close(); conn.close()
    flash("节点已删除","success")
    return redirect(url_for("nodes_page"))

#----节点修改按钮
@app.route("/node_update", methods=["POST"])
@login_required
def node_update():
    node_id = request.form.get("id")
    host = request.form.get("host", "").strip()
    node = request.form.get("node", "").strip()
    token_name = request.form.get("token_name", "").strip()
    token_value = request.form.get("token_value", "").strip()

    if not node_id or not host or not node:
        flash("ID、主机IP和节点名不能为空", "danger")
        return redirect(url_for("nodes_page"))

    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        UPDATE vdi_proxmox_nodes
        SET host = %s, node = %s, token_name = %s, token_value = %s
        WHERE id = %s
    """, (host, node, token_name, token_value, node_id))
    conn.commit()
    cur.close()
    conn.close()

    flash("节点信息已更新", "success")
    return redirect(url_for("nodes_page"))


@app.route("/api/node_load")
@login_required
def api_node_load():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_proxmox_nodes WHERE enabled=1")
    nodes=cur.fetchall(); cur.close(); conn.close()
    result=[]
    for n in nodes:
        try:
            pm=PM(n)
            status=pm.get_node_status()
            result.append({"id":n["id"], "node":n["node"], "cpu":status.get("cpu",0),
                           "memory":status.get("memory_percent",0)})
        except:
            result.append({"id":n["id"], "node":n["node"], "cpu":-1, "memory":-1})
    return jsonify(result)

@app.route("/notify")
@login_required
def notify_page():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_notify_config")
    configs=cur.fetchall(); cur.close(); conn.close()
    return render_template("notify.html", configs=configs)

@app.route("/notify_save", methods=["POST"])
@login_required
def notify_save():
    webhook_url=request.form.get("webhook_url","").strip()
    test=request.form.get("test")
    conn=get_db(); cur=conn.cursor()
    if webhook_url:
        cur.execute("""INSERT INTO vdi_notify_config (type, enabled, config)
                       VALUES ('webhook', 1, %s)
                       ON DUPLICATE KEY UPDATE config=VALUES(config), enabled=1""",
                    (json.dumps({"webhook_url": webhook_url}),))
    conn.commit(); cur.close(); conn.close()
    if test and webhook_url:
        try:
            http_requests.post(webhook_url, json={"message": "VDI 通知测试"}, timeout=5)
            flash("测试通知已发送","success")
        except Exception as e:
            flash(f"测试失败: {e}","danger")
    else:
        flash("通知配置已保存","success")
    return redirect(url_for("notify_page"))

@app.route("/backup")
@login_required
def backup_page():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_backup_log ORDER BY created_at DESC LIMIT 20")
    logs=cur.fetchall(); cur.close(); conn.close()
    return render_template("backup.html", logs=logs)

@app.route("/backup_now", methods=["POST"])
@login_required
def backup_now():
    import subprocess, os
    try:
        now = datetime.now()
        filename = f"vdi_backup_{now.strftime('%Y%m%d_%H%M%S')}.sql.gz"
        backup_dir = "/opt/vdi-deploy/backups"
        os.makedirs(backup_dir, exist_ok=True)
        filepath = os.path.join(backup_dir, filename)
        db = CONFIG["database"]
        cmd = f"docker exec guac-mysql mysqldump -u{db['user']} -p{db['password']} {db['database']} | gzip > {filepath}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            error_msg = result.stderr.strip() or "未知错误（请检查 Docker 是否运行以及数据库配置）"
            flash(f"备份失败: {error_msg}", "danger")
            logging.error(f"备份命令失败，返回码 {result.returncode}，错误: {result.stderr}")
            return redirect(url_for("backup_page"))
        size = os.path.getsize(filepath)
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO vdi_backup_log (filename, size, type, created_at) VALUES (%s,%s,%s,%s)",
                    (filename, size, 'manual', now.strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        cur.close()
        conn.close()
        flash(f"备份完成: {filename} (大小: {size} B)", "success")
    except Exception as e:
        flash(f"备份失败: {str(e)}", "danger")
        logging.error(f"备份异常: {e}")
    return redirect(url_for("backup_page"))

@app.route("/backup_delete/<filename>", methods=["POST"])
@login_required
def backup_delete(filename):
    safe_filename = os.path.basename(filename)
    if not safe_filename:
        flash("无效的文件名", "danger")
        return redirect(url_for("backup_page"))
    backup_dir = "/opt/vdi-deploy/backups"
    filepath = os.path.join(backup_dir, safe_filename)
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM vdi_backup_log WHERE filename = %s", (safe_filename,))
        conn.commit()
        cur.close()
        conn.close()
        flash(f"已删除备份: {safe_filename}", "success")
    except Exception as e:
        flash(f"删除失败: {str(e)}", "danger")
        logging.error(f"删除备份异常: {e}")
    return redirect(url_for("backup_page"))

@app.route("/backup_restore", methods=["POST"])
@login_required
def backup_restore():
    import tempfile
    try:
        filename = request.form.get("filename")
        if filename:
            filepath = os.path.join("/opt/vdi-deploy/backups", os.path.basename(filename))
            if not os.path.exists(filepath):
                flash("备份文件不存在", "danger")
                return redirect(url_for("backup_page"))
            success, msg = restore_backup(filepath)
            if success:
                flash(f"已恢复备份: {filename}", "success")
            else:
                flash(f"恢复失败: {msg}", "danger")
            return redirect(url_for("backup_page"))
        if 'restore_file' not in request.files:
            flash("未选择文件", "warning")
            return redirect(url_for("backup_page"))
        file = request.files['restore_file']
        if file.filename == '':
            flash("未选择文件", "warning")
            return redirect(url_for("backup_page"))
        allowed_extensions = {'.sql', '.gz'}
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in allowed_extensions:
            flash("只支持 .sql 或 .gz 格式的备份文件", "danger")
            return redirect(url_for("backup_page"))
        temp_dir = tempfile.mkdtemp(prefix="vdi_restore_")
        temp_file_path = os.path.join(temp_dir, file.filename)
        file.save(temp_file_path)
        success, msg = restore_backup(temp_file_path)
        try:
            os.remove(temp_file_path)
            os.rmdir(temp_dir)
        except:
            pass
        if success:
            flash(f"已成功恢复上传的备份: {file.filename}", "success")
        else:
            flash(f"恢复失败: {msg}", "danger")
        return redirect(url_for("backup_page"))
    except Exception as e:
        flash(f"恢复操作出错: {str(e)}", "danger")
        logging.error(f"恢复异常: {e}")
        return redirect(url_for("backup_page"))

from flask import send_from_directory, abort
import os

@app.route("/backup_download/<filename>")
@login_required
def backup_download(filename):
    backup_dir = "/opt/vdi-deploy/backups"
    safe_filename = os.path.basename(filename)
    if not safe_filename:
        abort(404)
    filepath = os.path.join(backup_dir, safe_filename)
    if not os.path.isfile(filepath):
        abort(404)
    return send_from_directory(backup_dir, safe_filename, as_attachment=True)

@app.route("/tenant")
@login_required
def tenant_page():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vdi_tenant ORDER BY name")
    tenants=cur.fetchall(); cur.close(); conn.close()
    return render_template("tenant.html", tenants=tenants)

@app.route("/tenant_add", methods=["POST"])
@login_required
def tenant_add():
    name=request.form.get("name","").strip(); desc=request.form.get("description","").strip()
    if name:
        conn=get_db(); cur=conn.cursor()
        cur.execute("INSERT INTO vdi_tenant (name, description) VALUES (%s,%s)", (name, desc))
        conn.commit(); cur.close(); conn.close()
        flash("租户已添加","success")
    return redirect(url_for("tenant_page"))

@app.route("/tenant_delete", methods=["POST"])
@login_required
def tenant_delete():
    tid=int(request.form.get("tid",0))
    conn=get_db(); cur=conn.cursor()
    cur.execute("DELETE FROM vdi_tenant WHERE id=%s", (tid,))
    conn.commit(); cur.close(); conn.close()
    flash("租户已删除","success")
    return redirect(url_for("tenant_page"))

@app.route("/performance")
@login_required
def performance_page():
    return render_template("performance.html")

@app.route("/api/vm_stats/<int:vmid>")
@login_required
def api_vm_stats(vmid):
    try:
        pm = PM()
        rrd = pm.get_vm_rrd(vmid, "hour")
        if not rrd:
            return jsonify({"error": "无数据"}), 404
        data = []
        for item in rrd:
            ts = item.get("time")
            if ts and ts > 1e12:
                ts = int(ts)
            elif ts:
                ts = int(ts) * 1000
            data.append({
                "time": ts,
                "cpu": round(item.get("cpu", 0) * 100, 1),
                "mem": round(item.get("mem", 0) / 1024 / 1024, 1),
                "disk": round(item.get("disk", 0) / 1024 / 1024, 1),
                "netin": round(item.get("netin", 0) / 1024, 1),
                "netout": round(item.get("netout", 0) / 1024, 1)
            })
        return jsonify({"data": data})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/change_password", methods=["POST"])
@login_required
def change_admin_password():
    new_password=request.form.get("new_password","").strip()
    if new_password:
        import yaml
        config_path=os.environ.get("VDI_CONFIG","/opt/vdi-deploy/vdi-web/config.yaml")
        with open(config_path,'r') as f:
            config=yaml.safe_load(f)
        config["web"]["admin_password"]=new_password
        with open(config_path,'w') as f:
            yaml.dump(config, f)
        CONFIG["web"]["admin_password"]=new_password
        flash("密码修改成功，下次登录请使用新密码","success")
    return redirect(url_for("index"))

@app.route("/stats")
@login_required
def usage_stats():
    conn=get_db(); cur=conn.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) as total FROM vdi_desktop_usage WHERE action='connect'")
    total_connects=cur.fetchone()["total"]
    cur.execute("""SELECT u.connection_id, c.connection_name, COUNT(*) as count
                   FROM vdi_desktop_usage u
                   LEFT JOIN guacamole_connection c ON u.connection_id=c.connection_id
                   WHERE u.action='connect'
                   GROUP BY u.connection_id ORDER BY count DESC LIMIT 10""")
    top_desktops=cur.fetchall()
    cur.execute("""SELECT DATE(created_at) as date, COUNT(DISTINCT username) as users
                   FROM vdi_desktop_usage
                   WHERE action='connect' AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)
                   GROUP BY DATE(created_at) ORDER BY date""")
    daily_users=cur.fetchall()
    cur.close(); conn.close()
    return render_template("stats.html", total_connects=total_connects,
                           top_desktops=top_desktops, daily_users=daily_users)

if not scheduler.running:
    scheduler.start()
    logging.info("后台调度器已启动")

if __name__ == "__main__":
    app.run(host=CONFIG["web"]["listen_host"], port=CONFIG["web"]["listen_port"])