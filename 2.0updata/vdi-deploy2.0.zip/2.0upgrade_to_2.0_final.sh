#!/bin/bash
# ============================================================
# PVE云桌面管理平台VDI-WEB 云桌面平台 1.8 → 2.0 最终升级脚本
# 功能：数据库升级 + 功能扩展（不会对当前数据造成破坏影响）
# 执行前会自动备份，支持回滚
# ============================================================

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok() { echo -e "${GREEN}✔${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
err() { echo -e "${RED}✘${NC} $1"; exit 1; }

DEPLOY_DIR="/opt/vdi-deploy"
VDI_WEB="${DEPLOY_DIR}/vdi-web"
BACKUP_DIR="${DEPLOY_DIR}/upgrade_backup_$(date +%Y%m%d_%H%M%S)"

echo -e "\n${GREEN}=== VDI 1.8 → 2.0 最终升级开始 ===${NC}\n"

# 1. 备份
ok "正在备份现有文件..."
mkdir -p "$BACKUP_DIR"
cp "$VDI_WEB/app.py" "$BACKUP_DIR/app.py.bak" 2>/dev/null || true
cp -r "$VDI_WEB/templates" "$BACKUP_DIR/templates.bak" 2>/dev/null || true
ok "备份已保存至 $BACKUP_DIR"

# 2. 数据库变更（新增表、字段）
ok "正在更新数据库结构..."
source "$DEPLOY_DIR/config.env"
docker exec -i guac-mysql mysql -u root -p"$MYSQL_ROOT_PASSWORD" guacamole_db << 'EOF'
-- 分组表
CREATE TABLE IF NOT EXISTS vdi_desktop_group (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(64) NOT NULL UNIQUE,
    description VARCHAR(256),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Proxmox 节点表
CREATE TABLE IF NOT EXISTS vdi_proxmox_nodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    host VARCHAR(64) NOT NULL,
    node VARCHAR(32) NOT NULL,
    user VARCHAR(64) DEFAULT 'root@pam',
    token_name VARCHAR(64),
    token_value VARCHAR(128),
    default_storage VARCHAR(32) DEFAULT 'local-lvm',
    enabled TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 备份日志表
CREATE TABLE IF NOT EXISTS vdi_backup_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(128) NOT NULL,
    size BIGINT DEFAULT 0,
    type VARCHAR(16) DEFAULT 'manual',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 通知配置表
CREATE TABLE IF NOT EXISTS vdi_notify_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(16) NOT NULL,
    enabled TINYINT DEFAULT 1,
    config TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 租户表
CREATE TABLE IF NOT EXISTS vdi_tenant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(64) NOT NULL UNIQUE,
    description VARCHAR(256),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 申请表中增加字段（兼容 MySQL 5.7）
ALTER TABLE vdi_desktop_request ADD COLUMN node_id VARCHAR(32) DEFAULT NULL;
ALTER TABLE vdi_desktop_request ADD COLUMN group_id VARCHAR(32) DEFAULT NULL;
ALTER TABLE vdi_desktop_request ADD COLUMN expire_at DATETIME DEFAULT NULL;

USE guacamole_db;
ALTER TABLE vdi_schedule ADD COLUMN node_id INT NULL DEFAULT NULL COMMENT '节点ID';
EOF
ok "数据库结构已更新"

# 3. 修复 app.py（增量修补，不覆盖整个文件）
ok "请手动覆盖app.py和templates文件夹"

# 4. 重启服务
ok "正在重启 VDI Web 服务..."
systemctl restart vdi-web
sleep 3
if systemctl is-active --quiet vdi-web; then
    ok "VDI Web 服务已重启"
else
    warn "服务重启失败，请检查日志: journalctl -u vdi-web"
fi



# ==================== 5. 完成 ====================
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   VDI v2.0 升级成功！                  ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════╝${NC}"
echo ""
echo "新增功能访问地址："
echo "  📂 分组管理: http://$(hostname -I | awk '{print $1}')/groups"
echo "  💾 备份管理: http://$(hostname -I | awk '{print $1}')/backup"
echo "  🖥️ 节点管理: http://$(hostname -I | awk '{print $1}')/nodes"
echo "  🔔 通知配置: http://$(hostname -I | awk '{print $1}')/notify"
echo "  🏢 租户管理: http://$(hostname -I | awk '{print $1}')/tenants"
echo "  ✅ 用户申请: http://$(hostname -I | awk '{print $1}')//request"
echo "  ✅ 到期桌面自动销毁（约1分钟后生效）"
echo ""
echo "回滚命令（如需要）："
echo "  cp $BACKUP_DIR/app.py.bak $VDI_WEB/app.py"
echo "  cp -r $BACKUP_DIR/templates.bak/* $VDI_WEB/templates/"
echo ""
echo "  systemctl restart vdi-web 重启服务后验证所有功能"
echo "请刷新首页 http://$(hostname -I | awk '{print $1}')/ 验证所有功能。"